//const url = 'http://localhost:3000';
const protocol = window && window.location.protocol;

// export const BASE_API_URL = protocol;

export const BASE_API_URL = "http://20.81.65.239:8080" // backend service IP address
